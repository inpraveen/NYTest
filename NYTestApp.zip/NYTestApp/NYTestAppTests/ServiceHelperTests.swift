//
//  ServiceHelperTests.swift
//  NYTestAppTests
//
//  Created by Praveen Kumar on 02/03/20.
//  Copyright © 2020 Praveen Kumar. All rights reserved.
//

import XCTest

@testable import NYTestApp

class ServiceHelperTests: XCTestCase {
    
    func testCancelRequest() {
        
        // giving a "previous" session
        ServiceHelper.shared.fetchArticles { (_) in
            // ignore call
        }
        
        // Expected to task nil after cancel
        ServiceHelper.shared.cancelFetchArticles()
        XCTAssertNil(ServiceHelper.shared.task, "Expected task nil")
    }
}

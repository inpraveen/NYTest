//
//  RequestFactory.swift
//  NYTestApp
//
//  Created by Praveen Kumar on 02/03/20.
//  Copyright © 2020 Praveen Kumar. All rights reserved.
//

import Foundation

final class RequestFactory {
    
    enum Method: String {
        case GET
        case POST
    }
    
    static func request(method: Method, url: URL) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        return request
    }
}
